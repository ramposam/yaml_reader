import yaml
import os


def read_yaml_file(file_path):
    """Reads a YAML file and returns its content as a dictionary."""
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"The file {file_path} does not exist.")

    with open(file_path, 'r') as file:
        try:
            data = yaml.safe_load(file)
            return data
        except yaml.YAMLError as e:
            raise ValueError(f"Error decoding YAML from file {file_path}: {e}")


def read_yaml_from_folder(folder_path):
    """Reads all YAML files in a folder and returns their content as a list of dictionaries."""
    if not os.path.isdir(folder_path):
        raise NotADirectoryError(f"The folder {folder_path} does not exist.")

    data_list = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".yml") or filename.endswith(".yaml"):
            file_path = os.path.join(folder_path, filename)
            data = read_yaml_file(file_path)
            data_list.append(data)

    return data_list
